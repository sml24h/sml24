module.exports = {
  "globDirectory": "_site/",
  "globPatterns": [
    "**/*.{css,png,js,ico,html,webmanifest}"
  ],
  "swDest": "sw.js"
};
